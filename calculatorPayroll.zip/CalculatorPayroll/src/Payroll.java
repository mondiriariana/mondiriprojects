package activity20;

import java.util.Scanner;

public class Payroll {
	public final int NUM_EMPLOYEES = 7; // Number of employees
	private int[] employeeId = { 5658845, 4520125, 7895122,
                             8777541, 8451277, 1302850,
                             7580489 };
	private int[] hours = new int[NUM_EMPLOYEES];
	private double[] payRate = new double[NUM_EMPLOYEES];
	private double[] wages = new double[NUM_EMPLOYEES];

	public double getGrossPay(int i){
		return hours[i] * payRate[i];
	}
	public void setEmployeeIdAt(int i, int id){
		employeeId[i] = id;
	}
	public void setHoursAt(int i, int h){
		hours[i] = h;
	}
	public void setPayRateAt(int i, double p){
		payRate[i] = p;
	}
	public void setWages(int i, double w){
		wages[i] = w;
	}
	public int getEmployeeIdAt(int i){
		return employeeId[i];
	}
	public int getHoursAt(int i){
		return hours[i];
	}
	public double getPayRateAt(int i){
		return payRate[i];
	}
	public double getWages(int i){
		return wages[i];
	}
	}



